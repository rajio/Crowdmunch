(function(window, document) {

  'use strict';

  //= ../features.js
  //= ../Debouncer.js
  //= ../Headroom.js

  window.Headroom = Headroom;

}(window, document));